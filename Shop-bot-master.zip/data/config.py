BOT_TOKEN = '6907708979:AAGCe7Kvt0C-r7xzfms1iKyFk1EmdizEUxs'

PROJECT_NAME = 'Computer_wizardBot'

WEBHOOK_HOST = f"https://www.computer-technician.online"
WEBHOOK_PATH = '/webhook/' + BOT_TOKEN
WEBHOOK_URL = f'https://api.telegram.org/bot6907708979:AAGCe7Kvt0C-r7xzfms1iKyFk1EmdizEUxs/setWebhook?url=https://www.computer-technician.online/my-telegram-bot'

ADMINS = [1429052804, 1429052804]
