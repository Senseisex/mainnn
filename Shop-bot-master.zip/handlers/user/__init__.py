from .menu import dp
from .cart import dp
from .wallet import dp
from .catalog import dp
from .delivery_status import dp
from .sos import dp

__all__ = ['dp']